<?php $__env->startSection('page_title'); ?>
Daftar Tempat Kuliner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
      <div class="col-md-9 text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
        <!-- <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.html">Home</a></span> <span>Hotel</span></p> -->
        <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Daftar Kuliner yang tersedia</h1>
      </div>
    </div>
  </div>
</div>

<div class="col-lg-9">
  <div class="row">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm col-md-6 col-lg-4 ftco-animate">
  		    				<div class="destination">
  		    					<a href="/Detail_Kuliner/<?php echo e($value->id); ?>" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(image/kuliner/<?php echo e($value->image); ?>);">
  		    						<div class="icon d-flex justify-content-center align-items-center">
  		    							<span class="icon-link"></span>
  		    						</div>
  		    					</a>
  		    					<div class="text p-3">
  		    						<div class="d-flex">
  		    							<div class="one">
  				    						<h3><?php echo e($value->nama); ?></h3>
  				    						<p class="rate">
  				    							<span><?php echo e($value->kota); ?></span>
  				    						</p>
  			    						</div>
  			    						<div class="two">
  			    							<span class="price per-price">Rp.<?php echo e($value->tarif_bawah); ?> <br><small>Mulai dari</small></span>
  		    							</div>
  		    						</div>
  		    						<p><?php echo e($value->alamat); ?></p>
  		    						<hr>
  		    						<p class="bottom-area d-flex">
  		    							<span><i class="icon-map-o"></i> <?php echo e($value->kecamatan); ?></span>
  		    							<span class="ml-auto"><a href="/Detail_Hotel/<?php echo e($value->id); ?>">Lihat Detail</a></span>
  		    						</p>
  		    					</div>
  		    				</div>
  		    			</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tunjuk.in\resources\views/KulinerList.blade.php ENDPATH**/ ?>