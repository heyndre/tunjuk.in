<?php $__env->startSection('page_title'); ?>
Tambah Hotel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Username'); ?>
<?php $nama = Auth::user()->name?>
<?php echo $nama?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<!-- <ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
  <li><a href="#">Examples</a></li>
  <li class="active">Blank page</li>
</ol> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<section class="content">

  <!-- Default box -->
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Kelola Data Kategori</h3>

      <div class="box-tools pull-right">
        <a href="/hotel_admin" class="btn btn-box-tool"><i class="fa fa-plus-circle"></i>Batal</a>
        <!-- <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button> -->
      </div>
    </div>
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Tambah Kategori</h3>
      </div>

      <div class="box-body">
        <form role="form" method="POST" action="/kategori_admin" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="box-body">
            <div class="form-group">
              <label for="namaHotel">Nama Kategori</label>
              <input type="text" class="form-control" name="namaHotel" id="namaHotel" placeholder="Nama Hotel">
            </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>
        <!-- <form>
          <div class="form-group">
            <label for="exampleInputFile">Gambar Hotel</label>
            <input type="file" id="exampleInputFile">

            <p class="help-block">Masukkan gambar hotel</p>
          </div>
        </form> -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tunjuk.in\resources\views/admin_kategori_tambah.blade.php ENDPATH**/ ?>