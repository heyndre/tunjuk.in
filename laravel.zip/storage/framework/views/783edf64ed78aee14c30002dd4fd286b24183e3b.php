<?php $__env->startSection('page_title'); ?>
Daftar Tempat Kuliner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Username'); ?>
<?php $nama = Auth::user()->name?>
<?php echo $nama?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<!-- <ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
  <li><a href="#">Examples</a></li>
  <li class="active">Blank page</li>
</ol> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">

  <!-- Default box -->
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Kelola Data Tempat Kuliner</h3>

      <div class="box-tools pull-right">
        <a href="/kuliner_admin/create" class="btn btn-box-tool"><i class="fa fa-plus-circle"></i> Tambah Tempat Kuliner</a>
        <!-- <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button> -->
      </div>
    </div>
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Daftar Tempat Kuliner</h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body" style="overflow-x:auto;">
        <table id="example2" class="table table-bordered table-hover">
          <thead>
          <tr>
            <th>Nomor</th>
            <th>Tampilan</th>
            <th>Nama Tempat Kuliner</th>
            <th>Alamat</th>
            <th>Kecamatan</th>
            <th>Kode Pos</th>
            <th>Kota</th>
            <th>Koordinat</th>
            <th>Tarif atas</th>
            <th>Tarif bawah</th>
            <!-- <th>Jam Buka</th>
            <th>Jam Tutup</th> -->
            <th>Verifikasi</th>
            <th>Opsi</th>
          </tr>
          </thead>
          <tbody>
            <?php $number=0?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th><?php echo e(++$number); ?></th>
              <th><img src="<?php echo e(asset('image/kuliner/'.$value->image)); ?>" height="50px"></th>
              <th><?php echo e($value->nama); ?></th>
              <th><?php echo e($value->alamat); ?></th>
              <th><?php echo e($value->kecamatan); ?></th>
              <th><?php echo e($value->kode_pos); ?></th>
              <th><?php echo e($value->kota); ?></th>
              <th><?php echo e($value->latitude); ?>, <?php echo e($value->longitude); ?></th>
              <th><?php echo e($value->tarif_atas); ?></th>
              <th><?php echo e($value->tarif_bawah); ?></th>
              <!-- <th><?php echo e($value->jam_buka); ?></th>
              <th><?php echo e($value->jam_tutup); ?></th> -->
              <th><?php if($value->verified=='1'): ?> <?php echo"Terverifikasi"?>
                  <?php elseif($value->verified=='0'): ?> <?php echo "Belum Diverifikasi"?>
                  <?php endif; ?>
              </th>
              <th>
                <a href="<?php echo e(route('kuliner_admin.edit', ['kuliner_admin' => $value->id])); ?>">Ubah / Hapus</a>
                <!-- <br> -->
                <!-- <a href="#" onclick="event.preventDefault(); if(confirm('Konfirmasi Penghapusan Data')) {$('form#hapus').attr('action', '<?php echo e(route('hotel_admin.destroy', ['hotel_admin' => $value->id])); ?>').submit(); location.reload();}">Hapus</a> -->
              </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th>Nomor</th>
              <th>Tampilan</th>
              <th>Nama Tempat Kuliner</th>
              <th>Alamat</th>
              <th>Kecamatan</th>
              <th>Kode Pos</th>
              <th>Kota</th>
              <th>Koordinat</th>
              <th>Tarif atas</th>
              <th>Tarif bawah</th>
              <th>Verifikasi</th>
              <th>Opsi</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tunjuk.in\resources\views/admin_kuliner_list.blade.php ENDPATH**/ ?>