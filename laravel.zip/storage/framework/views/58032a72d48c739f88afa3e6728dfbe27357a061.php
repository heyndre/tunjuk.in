<?php $__env->startSection('page_title'); ?>
Ubah Tempat Kuliner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Username'); ?>
<?php $nama = Auth::user()->name?>
<?php echo $nama?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<!-- <ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
  <li><a href="#">Examples</a></li>
  <li class="active">Blank page</li>
</ol> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">

  <!-- Default box -->
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Kelola Data Tempat Kuliner</h3>

      <!-- <div class="box-tools pull-right">
        <a href="/hotel_admin" class="btn btn-box-tool"><i class="fa fa-plus-cross"></i>Batal</a>
      </div> -->
    </div>
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Ubah Data Kuliner <?php echo e($data->nama); ?></h3>
      </div>

      <div class="box-body">
        <form role="form" method="POST" action="<?php echo e(route('kuliner_admin.update', ['kuliner_admin' => $data->id])); ?>" enctype="multipart/form-data">
          <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>
          <div class="box-body">
            <label for="exampleInputFile">Gambar Kuliner</label>
            <div class="form-group">
                <img src="<?php echo e(asset('image/kuliner/'.$data->image)); ?>" height="300px">
                <input type="file" name="gambarKuliner" id="gambarKuliner">
              <p class="help-block">Ubah gambar tempat kuliner</p>
            </div>
          </div>
            <div class="form-group">
              <label for="namaHotel">Nama Kuliner</label>
              <input type="text" class="form-control" name="namaKuliner" id="namaKuliner" placeholder="Nama Tempat Kuliner" value="<?php echo e($data->nama); ?>">
            </div>
            <div class="form-group">
              <label for="alamatHotel">Alamat</label>
              <input type="text" class="form-control" name="alamatKuliner" accept="" id="alamatKuliner" placeholder="Alamat Kuliner" value="<?php echo e($data->alamat); ?>">
            </div>
            <!-- <div class="form-group">
              <label for="kecamatanHotel">Kecamatan</label>
              <input type="text" class="form-control" name="kecamatanKuliner" id="kecamatanKuliner" placeholder="Kecamatan Hotel" value="<?php echo e($data->kecamatan); ?>">
            </div> -->
            <div class="form-group">
              <label>Kecamatan</label>
              <select name="kecamatanKuliner" id="kecamatanKuliner" class="form-control" value="<?php echo e($data->kecamatan); ?>">
                <?php $__currentLoopData = $kec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kcm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($kcm->nama_kecamatan == $data->kecamatan): ?>
                <option value="<?php echo e($kcm->nama_kecamatan); ?>" selected><?php echo e($kcm->nama_kecamatan); ?></option>
                <?php else: ?>
                <option value="<?php echo e($kcm->nama_kecamatan); ?>"><?php echo e($kcm->nama_kecamatan); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="kodePosHotel">Kode Pos</label>
              <input type="text" class="form-control" name="kodePosKuliner" id="kodePosKuliner" placeholder="Kode Pos Hotel" value="<?php echo e($data->kode_pos); ?>">
            </div>
            <div class="form-group">
              <label for="kotaHotel">Kota</label>
              <input type="text" class="form-control" name="kotaKuliner" id="kotaKuliner" placeholder="Jember" value="<?php echo e($data->kota); ?>" disabled>
            </div>
            <div class="form-group">
              <label for="lintangHotel">Koordinat lintang</label>
              <input type="text" class="form-control" name="lintangKuliner" id="lintangKuliner" placeholder="Latitude" value="<?php echo e($data->latitude); ?>">
            </div>
            <div class="form-group">
              <label for="bujurHotel">Koordinat Bujur</label>
              <input type="text" class="form-control" name="bujurKuliner" id="bujurKuliner" placeholder="Longitude" value="<?php echo e($data->longitude); ?>">
            </div>
            <div class="form-group">
              <label for="tarifAtas">Tarif Atas</label>
              <input type="text" class="form-control" name="tarifAtas" id="tarifAtas" placeholder="Tarif Atas" value="<?php echo e($data->tarif_atas); ?>">
            </div>
            <div class="form-group">
              <label for="tarifBawah">Tarif Bawah</label>
              <input type="text" class="form-control" name="tarifBawah" id="tarifBawah" placeholder="Tarif Bawah" value="<?php echo e($data->tarif_bawah); ?>">
            </div>
            <div class="form-group">
              <label>Deskripsi</label>
              <textarea class="form-control" rows="3" name="deskripsiKuliner" id="deskripsiKuliner" placeholder="Deskripsi Hotel"><?php echo e($data->deskripsi); ?></textarea>
            </div>
          <div class="form-group">
            <?php if($data->verified=='1'): ?>
            <div class="radio">
              <label>
                <input type="radio" name="verify" id="optionsRadios1" value="0" >
                Belum Diverifikasi
              </label>
            </div>
            <div class="radio">
              <label>
                <input type="radio" name="verify" id="optionsRadios2" value="1" checked>
                Terverifikasi
              </label>
          </div>
          <?php elseif($data->verified=='0'): ?>
          <div class="radio">
            <label>
              <input type="radio" name="verify" id="optionsRadios1" value="0" checked>
              Belum Diverifikasi
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" name="verify" id="optionsRadios2" value="1">
              Terverifikasi
            </label>
        </div>
        <?php endif; ?>
        </div>

          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>
        <div class="box-footer">
          <label>
            <a href="/hotel_admin">
          <input type="button" class="btn btn-secondary" value="Batal">
        </a>
          </label>
        </div>
        <div>
          <form id="hapus" method="post" action="<?php echo e(route('hotel_admin.destroy', ['hotel' => $data->id])); ?>" style="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="box-footer">
            <button type="submit" class="btn btn-warning" onclick="clicked(event)"> HAPUS </button>
          </div>
          </form>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->

</section>
<script>
function clicked(e)
{
    if(!confirm('KONFIRMASI PENGHAPUSAN DATA'))e.preventDefault();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tunjuk.in\resources\views/admin_kuliner_ubah.blade.php ENDPATH**/ ?>