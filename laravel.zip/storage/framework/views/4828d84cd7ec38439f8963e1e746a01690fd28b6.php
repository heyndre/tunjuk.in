<?php if(Auth::user()->privileged == '1'): ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$nama = Auth::user()->name;
// $priv = 1;
?>
<?php elseif(Auth::user()->privileged == '0'): ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$nama = Auth::user()->name;
// $priv = 0;
?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tunjuk.in\resources\views/home.blade.php ENDPATH**/ ?>