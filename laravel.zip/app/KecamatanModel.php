<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KecamatanModel extends Model
{
    protected $table='kecamatan';
    protected $primaryKey='id';

}
